//
//  PlayersTBVC.swift
//  M-Task
//
//  Created by Dhairya Vora on 06/07/23.
//

import UIKit

class PlayersTBVC: UITableViewCell {

    @IBOutlet weak var view: UIView!
    @IBOutlet weak var playerNameLBL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.view.layer.cornerRadius = 10
        self.selectionStyle = .none
    }
}
