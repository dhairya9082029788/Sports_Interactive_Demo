//
//  MatchDetailsTBVC.swift
//  M-Task
//
//  Created by Dhairya Vora on 06/07/23.
//

import UIKit

class MatchDetailsTBVC: UITableViewCell {
    @IBOutlet weak var matchDatenTimeLBL: UILabel!
    @IBOutlet weak var teamsLBL: UILabel!
    @IBOutlet weak var venueLBL: UILabel!
    @IBOutlet weak var view: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.view.layer.cornerRadius = 10
        self.selectionStyle = .none
    }
    
    //MARK: - Update UI
    internal func updateUI(matchDetails: Match?, venueDetail: Venue?, teamHome: String, teamAway: String){
        matchDatenTimeLBL.text = "Date : \(matchDetails?.date ?? "") | Time : \(matchDetails?.time ?? "")"
        teamsLBL.text = "\(teamHome) VS \(teamAway)"
        venueLBL.text = "\(venueDetail?.name ?? "")"
    }
}
