//
//  PlayersDetailVC.swift
//  M-Task
//
//  Created by Dhairya Vora on 06/07/23.
//

import UIKit

class PlayersDetailVC: UIViewController {
    @IBOutlet weak var playerNameLBL: UILabel!
    @IBOutlet weak var battingStyleLBL: UILabel!
    @IBOutlet weak var bowlingStyleLBL: UILabel!
    
    var cricketData: [String: Any] = ["name": String.self, "battingStyle": String.self, "bowlingStyle": String.self]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playerNameLBL.text = "Player Name : \(cricketData["name"] ?? "")"
        battingStyleLBL.text = "Batting Style : \(cricketData["battingStyle"] ?? "") "
        (cricketData["bowlingStyle"] as? String == "") ? ( bowlingStyleLBL.text = "Bowling Style : Doesnt Bowl") : (bowlingStyleLBL.text = "Bowling Style : \(cricketData["bowlingStyle"] ?? "")")
    }
}
