//
//  SportsDataManager.swift
//  M-Task
//
//  Created by Dhairya on 06/07/23.
//

import Foundation
import UIKit


class SportsDataManager {
    static let shared = SportsDataManager()
        
//    func sportsManager(url: String, completion: @escaping(ResultSet<ChallengeParticipientModel ,ServerError>) -> Void){
//        
//    }
}
